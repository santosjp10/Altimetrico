package br.edu.agronomia.levantamentoalt;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NmeaBridgePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
