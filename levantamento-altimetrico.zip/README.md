# Levantamento Altimétrico — Fase 1

App Android nativo para levantamento planialtimétrico por malha de pontos, com guiamento até cada
ponto e coleta automática por permanência (com média das leituras e descarte de outliers).

Mesma base do Coletor de Campo GNSS: Capacitor (HTML/JS embutido em app nativo) + GitHub Actions
para compilar o `.apk` na nuvem, sem precisar de Android Studio.

## Como publicar (2 arquivos apenas, testado e funcionando)

1. Crie um repositório novo no GitHub (pode ser privado).
2. **Add file → Upload files** → envie **apenas** o arquivo `levantamento-altimetrico.zip` (não descompacte, não envie pastas soltas) → **Commit changes**.
3. **Add file → Create new file** → nome do arquivo: `.github/workflows/build-apk.yml` (a barra já cria as pastas) → cole o conteúdo abaixo → **Commit changes**.

```yaml
name: Build APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch: {}

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Unzip project payload
        run: unzip -o levantamento-altimetrico.zip -d .

      - uses: actions/setup-node@v4
        with:
          node-version: 22

      - name: Set up JDK 21
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'

      - name: Install npm dependencies
        run: npm install

      - name: Sync Capacitor Android project
        run: npx cap sync android

      - name: Accept Android SDK licenses
        run: yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses || true

      - name: Grant execute permission for gradlew
        run: chmod +x android/gradlew

      - name: Build debug APK
        working-directory: android
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: levantamento-altimetrico-debug-apk
          path: android/app/build/outputs/apk/debug/app-debug.apk
```

4. Aba **Actions** → aguarde a build (3-8 min) → baixe o `.apk` em **Artifacts** → transfira para o
   celular e instale (autorize "instalar de fontes desconhecidas" para esse arquivo).

Para qualquer atualização futura: repita o passo 2 (apagar o zip antigo, subir o novo, **sem
esquecer o Commit changes**).

## Fluxo de uso

1. **Área** — desenhe o polígono no mapa, colete andando o limite, ou importe um GeoJSON.
2. **Malha** — escolha a finalidade/resolução (ou espaçamento manual) e gere a malha de pontos.
3. **Config** — confirme a conexão TCP com o GNSS Master, ajuste raio de captura / tempo de
   permanência / limiar de outlier, trava de qualidade, datum/MAPGEO2015 e dados do projeto.
4. **Campo** — a seta aponta para o ponto pendente mais próximo, com azimute e distância em
   números como apoio (a bússola do celular é auxiliar, não referência absoluta). Ao entrar no
   raio configurado, o app apita, vibra e conta regressivamente; ao final, grava a **média** das
   leituras (descartando outliers automaticamente).
5. **Mapa** — acompanhe pontos pendentes (cinza), coletados (verde) e pulados (vermelho) sobre
   satélite/ruas.
6. **Dados** — lista completa, estatísticas e exportação (CSV/GeoJSON/KML) via menu de
   compartilhamento do Android (inclui WhatsApp, e-mail, Google Drive etc.).

## O que fica para a Fase 2 e 3

- TIN (triangulação), curvas de nível com equidistância configurável, estatísticas altimétricas
  completas e perfil do terreno.
- Relatório PDF completo (mapa, curvas, perfil, estatísticas, memorial).

## Observação técnica sobre a malha

O teste de "ponto dentro do polígono" usa ray casting padrão (o mesmo método usado em qualquer
SIG). Pontos exatamente sobre uma aresta do polígono podem ficar de fora da malha por essa
ambiguidade matemática normal — por isso os **vértices do próprio polígono são sempre incluídos
como pontos obrigatórios**, garantindo que a borda da área nunca fique sem cobertura.
